Problem Statement
‘BeHealthy’ has a web platform that allows doctors to list their services and manage patient interactions and provides services for patients such as booking interactions with doctors and ordering medicines online. Here, doctors can easily organize appointments, track past medical records and provide e-prescriptions. The requirement is to build a custom NER to get the list of diseases and their treatment from the dataset.

Dataset
The dataset consist of four files containing words in line separate format:
train_sent
test_sent
train_label
test_label

Approach
Data preprocessing
Concept identification
Defining the features for CRF
Getting the features words and sentences
Defining input and target variables
Building the model
Evaluating the model
Identifying the diseases and predicted treatment using a custom NER

Results
F1 score of 90.43 is achieved